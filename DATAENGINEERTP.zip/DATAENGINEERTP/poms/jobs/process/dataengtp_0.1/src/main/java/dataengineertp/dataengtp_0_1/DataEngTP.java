// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package dataengineertp.dataengtp_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: DataEngTP Purpose: <br>
 * Description: TP du Data Engineering <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class DataEngTP implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "DataEngTP";
	private final String projectName = "DATAENGINEERTP";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					DataEngTP.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(DataEngTP.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterColumns_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputXML_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_6_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_6_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_6_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_7_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_7_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_7_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_8_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_8_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_8_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);

	}

	public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_9_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_9_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_9_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public long gainouperte;

		public long getGainouperte() {
			return this.gainouperte;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					this.gainouperte = dis.readLong();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					this.gainouperte = dis.readLong();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// long

				dos.writeLong(this.gainouperte);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// long

				dos.writeLong(this.gainouperte);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",gainouperte=" + String.valueOf(gainouperte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row15Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_9
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_9> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public long gainouperte;

		public long getGainouperte() {
			return this.gainouperte;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					this.gainouperte = dis.readLong();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					this.gainouperte = dis.readLong();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// long

				dos.writeLong(this.gainouperte);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// long

				dos.writeLong(this.gainouperte);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",gainouperte=" + String.valueOf(gainouperte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_9 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public int year;

		public int getYear() {
			return this.year;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public Integer countYear;

		public Integer getCountYear() {
			return this.countYear;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.countYear = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.countYear = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Integer

				writeInteger(this.countYear, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Integer

				writeInteger(this.countYear, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("year=" + String.valueOf(year));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",countYear=" + String.valueOf(countYear));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row14Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtAggregateRow_1
			implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public int year;

		public int getYear() {
			return this.year;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public Integer countYear;

		public Integer getCountYear() {
			return this.countYear;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.countYear = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.countYear = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Integer

				writeInteger(this.countYear, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Integer

				writeInteger(this.countYear, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("year=" + String.valueOf(year));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",countYear=" + String.valueOf(countYear));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public int year;

		public int getYear() {
			return this.year;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("year=" + String.valueOf(year));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_8
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_8> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public int year;

		public int getYear() {
			return this.year;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("year=" + String.valueOf(year));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_8 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_7
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_7> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_7 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_6
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_6> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_6 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class page1Struct implements routines.system.IPersistableRow<page1Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(page1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class page2Struct implements routines.system.IPersistableRow<page2Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public int year;

		public int getYear() {
			return this.year;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.year = dis.readInt();

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.budget = null;
					} else {
						this.budget = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.year);

				// String

				writeString(this.title, dos);

				// Long

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("year=" + String.valueOf(year));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(page2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class page3Struct implements routines.system.IPersistableRow<page3Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public String title;

		public String getTitle() {
			return this.title;
		}

		public long gainouperte;

		public long getGainouperte() {
			return this.gainouperte;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					this.gainouperte = dis.readLong();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

					this.gainouperte = dis.readLong();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// long

				dos.writeLong(this.gainouperte);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// long

				dos.writeLong(this.gainouperte);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",gainouperte=" + String.valueOf(gainouperte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(page3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];

		public Integer movieID;

		public Integer getMovieID() {
			return this.movieID;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movieID=" + String.valueOf(movieID));
			sb.append(",title=" + title);
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movieID;

		public Integer getMovieID() {
			return this.movieID;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movieID == null) ? 0 : this.movieID.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row5Struct other = (row5Struct) obj;

			if (this.movieID == null) {
				if (other.movieID != null)
					return false;

			} else if (!this.movieID.equals(other.movieID))

				return false;

			return true;
		}

		public void copyDataTo(row5Struct other) {

			other.movieID = this.movieID;
			other.title = this.title;
			other.release = this.release;
			other.errorMessage = this.errorMessage;

		}

		public void copyKeysDataTo(row5Struct other) {

			other.movieID = this.movieID;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.release = readDate(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.release = readDate(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.release, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.release, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movieID=" + String.valueOf(movieID));
			sb.append(",title=" + title);
			sb.append(",release=" + String.valueOf(release));
			sb.append(",errorMessage=" + errorMessage);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movieID, other.movieID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movieID;

		public Integer getMovieID() {
			return this.movieID;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movieID == null) ? 0 : this.movieID.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row21Struct other = (row21Struct) obj;

			if (this.movieID == null) {
				if (other.movieID != null)
					return false;

			} else if (!this.movieID.equals(other.movieID))

				return false;

			return true;
		}

		public void copyDataTo(row21Struct other) {

			other.movieID = this.movieID;
			other.title = this.title;
			other.release = this.release;

		}

		public void copyKeysDataTo(row21Struct other) {

			other.movieID = this.movieID;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movieID=" + String.valueOf(movieID));
			sb.append(",title=" + title);
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row21Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movieID, other.movieID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movieID;

		public Integer getMovieID() {
			return this.movieID;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer C;

		public Integer getC() {
			return this.C;
		}

		public String D;

		public String getD() {
			return this.D;
		}

		public String E;

		public String getE() {
			return this.E;
		}

		public String F;

		public String getF() {
			return this.F;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movieID == null) ? 0 : this.movieID.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row1Struct other = (row1Struct) obj;

			if (this.movieID == null) {
				if (other.movieID != null)
					return false;

			} else if (!this.movieID.equals(other.movieID))

				return false;

			return true;
		}

		public void copyDataTo(row1Struct other) {

			other.movieID = this.movieID;
			other.title = this.title;
			other.C = this.C;
			other.D = this.D;
			other.E = this.E;
			other.F = this.F;
			other.release = this.release;

		}

		public void copyKeysDataTo(row1Struct other) {

			other.movieID = this.movieID;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movieID=" + String.valueOf(movieID));
			sb.append(",title=" + title);
			sb.append(",C=" + String.valueOf(C));
			sb.append(",D=" + D);
			sb.append(",E=" + E);
			sb.append(",F=" + F);
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movieID, other.movieID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputExcel_1Struct
			implements routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movieID;

		public Integer getMovieID() {
			return this.movieID;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer C;

		public Integer getC() {
			return this.C;
		}

		public String D;

		public String getD() {
			return this.D;
		}

		public String E;

		public String getE() {
			return this.E;
		}

		public String F;

		public String getF() {
			return this.F;
		}

		public java.util.Date release;

		public java.util.Date getRelease() {
			return this.release;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movieID == null) ? 0 : this.movieID.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final after_tFileInputExcel_1Struct other = (after_tFileInputExcel_1Struct) obj;

			if (this.movieID == null) {
				if (other.movieID != null)
					return false;

			} else if (!this.movieID.equals(other.movieID))

				return false;

			return true;
		}

		public void copyDataTo(after_tFileInputExcel_1Struct other) {

			other.movieID = this.movieID;
			other.title = this.title;
			other.C = this.C;
			other.D = this.D;
			other.E = this.E;
			other.F = this.F;
			other.release = this.release;

		}

		public void copyKeysDataTo(after_tFileInputExcel_1Struct other) {

			other.movieID = this.movieID;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movieID = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.release = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movieID, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.release, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movieID=" + String.valueOf(movieID));
			sb.append(",title=" + title);
			sb.append(",C=" + String.valueOf(C));
			sb.append(",D=" + D);
			sb.append(",E=" + E);
			sb.append(",F=" + F);
			sb.append(",release=" + String.valueOf(release));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputExcel_1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movieID, other.movieID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tFileInputDelimited_1Process(globalMap);
				tFileInputXML_1Process(globalMap);

				row1Struct row1 = new row1Struct();
				row21Struct row21 = new row21Struct();
				row2Struct row2 = new row2Struct();
				page1Struct page1 = new page1Struct();
				row11Struct row11 = new row11Struct();
				row12Struct row12 = new row12Struct();
				page2Struct page2 = new page2Struct();
				row13Struct row13 = new row13Struct();
				row14Struct row14 = new row14Struct();
				page3Struct page3 = new page3Struct();
				row15Struct row15 = new row15Struct();
				row5Struct row5 = new row5Struct();

				/**
				 * [tSortRow_6_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_6_SortOut", false);
				start_Hash.put("tSortRow_6_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_6";

				currentComponent = "tSortRow_6_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "page1");
				}

				int tos_count_tSortRow_6_SortOut = 0;

				class Comparablepage1Struct extends page1Struct implements Comparable<Comparablepage1Struct> {

					public int compareTo(Comparablepage1Struct other) {

						if (this.release == null && other.release != null) {
							return -1;

						} else if (this.release != null && other.release == null) {
							return 1;

						} else if (this.release != null && other.release != null) {
							if (!this.release.equals(other.release)) {
								return this.release.compareTo(other.release);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablepage1Struct> list_tSortRow_6_SortOut = new java.util.ArrayList<Comparablepage1Struct>();

				/**
				 * [tSortRow_6_SortOut begin ] stop
				 */

				/**
				 * [tSortRow_8_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_8_SortOut", false);
				start_Hash.put("tSortRow_8_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_8";

				currentComponent = "tSortRow_8_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "page2");
				}

				int tos_count_tSortRow_8_SortOut = 0;

				class Comparablepage2Struct extends page2Struct implements Comparable<Comparablepage2Struct> {

					public int compareTo(Comparablepage2Struct other) {

						if (this.year != other.year) {

							return this.year > other.year ? 1 : -1;

						}
						return 0;
					}
				}

				java.util.List<Comparablepage2Struct> list_tSortRow_8_SortOut = new java.util.ArrayList<Comparablepage2Struct>();

				/**
				 * [tSortRow_8_SortOut begin ] stop
				 */

				/**
				 * [tSortRow_9_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_9_SortOut", false);
				start_Hash.put("tSortRow_9_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_9";

				currentComponent = "tSortRow_9_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "page3");
				}

				int tos_count_tSortRow_9_SortOut = 0;

				class Comparablepage3Struct extends page3Struct implements Comparable<Comparablepage3Struct> {

					public int compareTo(Comparablepage3Struct other) {

						if (this.gainouperte != other.gainouperte) {

							return this.gainouperte > other.gainouperte ? 1 : -1;

						}
						return 0;
					}
				}

				java.util.List<Comparablepage3Struct> list_tSortRow_9_SortOut = new java.util.ArrayList<Comparablepage3Struct>();

				/**
				 * [tSortRow_9_SortOut begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) globalMap
						.get("tHash_Lookup_row3"));

				row3Struct row3HashKey = new row3Struct();
				row3Struct row3Default = new row3Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) globalMap
						.get("tHash_Lookup_row4"));

				row4Struct row4HashKey = new row4Struct();
				row4Struct row4Default = new row4Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
					int year;
					long gainouperte;
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				page1Struct page1_tmp = new page1Struct();
				page2Struct page2_tmp = new page2Struct();
				page3Struct page3_tmp = new page3Struct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileOutputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_1", false);
				start_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row5");
				}

				int tos_count_tFileOutputExcel_1 = 0;

				int columnIndex_tFileOutputExcel_1 = 0;
				boolean headerIsInserted_tFileOutputExcel_1 = false;

				int nb_line_tFileOutputExcel_1 = 0;

				String fileName_tFileOutputExcel_1 = "C:/Program Files/TOS_DI-8.0.1/studio/workspace/ancienfilmsavant2000.xls";
				java.io.File file_tFileOutputExcel_1 = new java.io.File(fileName_tFileOutputExcel_1);
				boolean isFileGenerated_tFileOutputExcel_1 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_1 = file_tFileOutputExcel_1.getParentFile();
				if (parentFile_tFileOutputExcel_1 != null && !parentFile_tFileOutputExcel_1.exists()) {

					parentFile_tFileOutputExcel_1.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_1 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_1 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_1 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_1.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_1 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_1)),
						true, workbookSettings_tFileOutputExcel_1);

				writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_1 == null) {
					writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_1.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_1 = new int[4];
				for (int i_tFileOutputExcel_1 = 0; i_tFileOutputExcel_1 < 4; i_tFileOutputExcel_1++) {
					int fitCellViewSize_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1
							.getColumnView(i_tFileOutputExcel_1).getSize();
					fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] = fitCellViewSize_tFileOutputExcel_1 / 256;
					if (fitCellViewSize_tFileOutputExcel_1 % 256 != 0) {
						fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_release_tFileOutputExcel_1 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				/**
				 * [tFileOutputExcel_1 begin ] stop
				 */

				/**
				 * [tFilterRow_1 begin ] start
				 */

				ok_Hash.put("tFilterRow_1", false);
				start_Hash.put("tFilterRow_1", System.currentTimeMillis());

				currentComponent = "tFilterRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row21");
				}

				int tos_count_tFilterRow_1 = 0;

				int nb_line_tFilterRow_1 = 0;
				int nb_line_ok_tFilterRow_1 = 0;
				int nb_line_reject_tFilterRow_1 = 0;

				class Operator_tFilterRow_1 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_1(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_1 begin ] stop
				 */

				/**
				 * [tFilterColumns_1 begin ] start
				 */

				ok_Hash.put("tFilterColumns_1", false);
				start_Hash.put("tFilterColumns_1", System.currentTimeMillis());

				currentComponent = "tFilterColumns_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tFilterColumns_1 = 0;

				int nb_line_tFilterColumns_1 = 0;

				/**
				 * [tFilterColumns_1 begin ] stop
				 */

				/**
				 * [tFileInputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileInputExcel_1", false);
				start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileInputExcel_1";

				int tos_count_tFileInputExcel_1 = 0;

				class RegexUtil_tFileInputExcel_1 {

					public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName,
							boolean useRegex) {

						java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

						if (useRegex) {// this part process the regex issue

							jxl.Sheet[] sheets = workbook.getSheets();
							java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
							for (int i = 0; i < sheets.length; i++) {
								String sheetName = sheets[i].getName();
								java.util.regex.Matcher matcher = pattern.matcher(sheetName);
								if (matcher.matches()) {
									jxl.Sheet sheet = workbook.getSheet(sheetName);
									if (sheet != null) {
										list.add(sheet);
									}
								}
							}

						} else {
							jxl.Sheet sheet = workbook.getSheet(oneSheetName);
							if (sheet != null) {
								list.add(sheet);
							}

						}

						return list;
					}

					public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
						java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();
						jxl.Sheet sheet = workbook.getSheet(index);
						if (sheet != null) {
							list.add(sheet);
						}
						return list;
					}

				}

				RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();
				final jxl.WorkbookSettings workbookSettings_tFileInputExcel_1 = new jxl.WorkbookSettings();
				workbookSettings_tFileInputExcel_1.setDrawingsDisabled(true);
				workbookSettings_tFileInputExcel_1.setEncoding("UTF-8");

				Object source_tFileInputExcel_1 = "C:/Users/willi/Documents/COURS Aivancity/Cours/Data Pipeline/Talend/moviesRelease.xls";
				final jxl.Workbook workbook_tFileInputExcel_1;

				java.io.InputStream toClose_tFileInputExcel_1 = null;
				java.io.BufferedInputStream buffIStreamtFileInputExcel_1 = null;
				try {
					if (source_tFileInputExcel_1 instanceof java.io.InputStream) {
						toClose_tFileInputExcel_1 = (java.io.InputStream) source_tFileInputExcel_1;
						buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
						workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1,
								workbookSettings_tFileInputExcel_1);
					} else if (source_tFileInputExcel_1 instanceof String) {
						toClose_tFileInputExcel_1 = new java.io.FileInputStream(source_tFileInputExcel_1.toString());
						buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
						workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1,
								workbookSettings_tFileInputExcel_1);
					} else {
						workbook_tFileInputExcel_1 = null;
						throw new java.lang.Exception(
								"The data source should be specified as Inputstream or File Path!");
					}
				} finally {
					try {
						if (buffIStreamtFileInputExcel_1 != null) {
							buffIStreamtFileInputExcel_1.close();
						}
					} catch (Exception e) {
						globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());
					}
				}
				try {
					java.util.List<jxl.Sheet> sheetList_tFileInputExcel_1 = java.util.Arrays.<jxl.Sheet>asList(
							workbook_tFileInputExcel_1.getSheets());
					if (sheetList_tFileInputExcel_1.size() <= 0) {
						throw new RuntimeException("Special sheets not exist!");
					}

					java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_1 = new java.util.ArrayList<jxl.Sheet>();
					for (jxl.Sheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
						if (sheet_FilterNull_tFileInputExcel_1.getRows() > 0) {
							sheet_FilterNullList_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
						}
					}
					sheetList_tFileInputExcel_1 = sheet_FilterNullList_tFileInputExcel_1;
					if (sheetList_tFileInputExcel_1.size() > 0) {
						int nb_line_tFileInputExcel_1 = 0;

						int begin_line_tFileInputExcel_1 = 0;

						int footer_input_tFileInputExcel_1 = 0;

						int end_line_tFileInputExcel_1 = 0;
						for (jxl.Sheet sheet_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
							end_line_tFileInputExcel_1 += sheet_tFileInputExcel_1.getRows();
						}
						end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
						int limit_tFileInputExcel_1 = -1;
						int start_column_tFileInputExcel_1 = 1 - 1;
						int end_column_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getColumns();
						jxl.Cell[] row_tFileInputExcel_1 = null;
						jxl.Sheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
						int rowCount_tFileInputExcel_1 = 0;
						int sheetIndex_tFileInputExcel_1 = 0;
						int currentRows_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getRows();

						// for the number format
						java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat(
								"#.####################################");
						char separatorChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols()
								.getDecimalSeparator();

						for (int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++) {

							int emptyColumnCount_tFileInputExcel_1 = 0;

							if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
								break;
							}

							while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
								rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
								sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1
										.get(++sheetIndex_tFileInputExcel_1);
								currentRows_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRows();
							}
							if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
								row_tFileInputExcel_1 = sheet_tFileInputExcel_1
										.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
							}
							globalMap.put("tFileInputExcel_1_CURRENT_SHEET", sheet_tFileInputExcel_1.getName());
							row1 = null;
							int tempRowLength_tFileInputExcel_1 = 7;

							int columnIndex_tFileInputExcel_1 = 0;

//
//end%>

							String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
							int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 > row_tFileInputExcel_1.length
									? row_tFileInputExcel_1.length
									: end_column_tFileInputExcel_1;

							java.util.TimeZone zone_tFileInputExcel_1 = java.util.TimeZone.getTimeZone("GMT");
							java.text.SimpleDateFormat sdf_tFileInputExcel_1 = new java.text.SimpleDateFormat(
									"dd-MM-yyyy");
							sdf_tFileInputExcel_1.setTimeZone(zone_tFileInputExcel_1);

							for (int i = 0; i < tempRowLength_tFileInputExcel_1; i++) {

								if (i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1) {

									jxl.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1[i
											+ start_column_tFileInputExcel_1];
									temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getContents();

								} else {
									temp_row_tFileInputExcel_1[i] = "";
								}
							}

							boolean whetherReject_tFileInputExcel_1 = false;
							row1 = new row1Struct();
							int curColNum_tFileInputExcel_1 = -1;
							String curColName_tFileInputExcel_1 = "";
							try {
								columnIndex_tFileInputExcel_1 = 0;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "movieID";
									row1.movieID = ParserUtils
											.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
								} else {
									row1.movieID = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 1;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "title";
									row1.title = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.title = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 2;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "C";
									row1.C = ParserUtils
											.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
								} else {
									row1.C = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 3;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "D";
									row1.D = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.D = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 4;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "E";
									row1.E = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.E = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 5;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "F";
									row1.F = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.F = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 6;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "release";
									if (6 < actual_end_column_tFileInputExcel_1) {
										try {
											java.util.Date dateGMT_tFileInputExcel_1 = ((jxl.DateCell) row_tFileInputExcel_1[columnIndex_tFileInputExcel_1
													+ start_column_tFileInputExcel_1]).getDate();
											row1.release = new java.util.Date(dateGMT_tFileInputExcel_1.getTime()
													- java.util.TimeZone.getDefault()
															.getOffset(dateGMT_tFileInputExcel_1.getTime()));
										} catch (java.lang.Exception e) {
											globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());

											throw new RuntimeException("The cell format is not Date in ( Row. "
													+ (nb_line_tFileInputExcel_1 + 1) + " and ColumnNum. "
													+ curColNum_tFileInputExcel_1 + " )");
										}
									}
								} else {
									row1.release = null;
									emptyColumnCount_tFileInputExcel_1++;
								}

								nb_line_tFileInputExcel_1++;

							} catch (java.lang.Exception e) {
								globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());
								whetherReject_tFileInputExcel_1 = true;
								System.err.println(e.getMessage());
								row1 = null;
							}

							/**
							 * [tFileInputExcel_1 begin ] stop
							 */

							/**
							 * [tFileInputExcel_1 main ] start
							 */

							currentComponent = "tFileInputExcel_1";

							tos_count_tFileInputExcel_1++;

							/**
							 * [tFileInputExcel_1 main ] stop
							 */

							/**
							 * [tFileInputExcel_1 process_data_begin ] start
							 */

							currentComponent = "tFileInputExcel_1";

							/**
							 * [tFileInputExcel_1 process_data_begin ] stop
							 */
// Start of branch "row1"
							if (row1 != null) {

								/**
								 * [tFilterColumns_1 main ] start
								 */

								currentComponent = "tFilterColumns_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row1"

									);
								}

								row21.movieID = row1.movieID;

								row21.title = row1.title;

								row21.release = row1.release;

								nb_line_tFilterColumns_1++;

								tos_count_tFilterColumns_1++;

								/**
								 * [tFilterColumns_1 main ] stop
								 */

								/**
								 * [tFilterColumns_1 process_data_begin ] start
								 */

								currentComponent = "tFilterColumns_1";

								/**
								 * [tFilterColumns_1 process_data_begin ] stop
								 */

								/**
								 * [tFilterRow_1 main ] start
								 */

								currentComponent = "tFilterRow_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row21"

									);
								}

								row5 = null;
								row2 = null;
								Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
								ope_tFilterRow_1.matches(
										(row21.release == null ? false
												: row21.release.compareTo(
														TalendDate.parseDate("dd-MM-yyyy", "31-12-1999")) >= 0),
										"release.compareTo(TalendDate.parseDate(\"dd-MM-yyyy\",\"31-12-1999\")) >= 0 failed");

								if (ope_tFilterRow_1.getMatchFlag()) {
									if (row2 == null) {
										row2 = new row2Struct();
									}
									row2.movieID = row21.movieID;
									row2.title = row21.title;
									row2.release = row21.release;
									nb_line_ok_tFilterRow_1++;
								} else {
									if (row5 == null) {
										row5 = new row5Struct();
									}
									row5.movieID = row21.movieID;
									row5.title = row21.title;
									row5.release = row21.release;
									row5.errorMessage = ope_tFilterRow_1.getErrorMsg();
									nb_line_reject_tFilterRow_1++;
								}

								nb_line_tFilterRow_1++;

								tos_count_tFilterRow_1++;

								/**
								 * [tFilterRow_1 main ] stop
								 */

								/**
								 * [tFilterRow_1 process_data_begin ] start
								 */

								currentComponent = "tFilterRow_1";

								/**
								 * [tFilterRow_1 process_data_begin ] stop
								 */
// Start of branch "row2"
								if (row2 != null) {

									/**
									 * [tMap_1 main ] start
									 */

									currentComponent = "tMap_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "row2"

										);
									}

									boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

									// ###############################
									// # Input tables (lookups)
									boolean rejectedInnerJoin_tMap_1 = false;
									boolean mainRowRejected_tMap_1 = false;

									///////////////////////////////////////////////
									// Starting Lookup Table "row3"
									///////////////////////////////////////////////

									boolean forceLooprow3 = false;

									row3Struct row3ObjectFromLookup = null;

									if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

										hasCasePrimitiveKeyWithNull_tMap_1 = false;

										row3HashKey.movie_id = row2.movieID;

										row3HashKey.hashCodeDirty = true;

										tHash_Lookup_row3.lookup(row3HashKey);

										if (!tHash_Lookup_row3.hasNext()) { // G_TM_M_090

											rejectedInnerJoin_tMap_1 = true;

										} // G_TM_M_090

									} // G_TM_M_020

									if (tHash_Lookup_row3 != null && tHash_Lookup_row3.getCount(row3HashKey) > 1) { // G
																													// 071

										// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row3'
										// and it contains more one result from keys : row3.movie_id = '" +
										// row3HashKey.movie_id + "'");
									} // G 071

									row3Struct row3 = null;

									row3Struct fromLookup_row3 = null;
									row3 = row3Default;

									if (tHash_Lookup_row3 != null && tHash_Lookup_row3.hasNext()) { // G 099

										fromLookup_row3 = tHash_Lookup_row3.next();

									} // G 099

									if (fromLookup_row3 != null) {
										row3 = fromLookup_row3;
									}

									///////////////////////////////////////////////
									// Starting Lookup Table "row4"
									///////////////////////////////////////////////

									boolean forceLooprow4 = false;

									row4Struct row4ObjectFromLookup = null;

									if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

										hasCasePrimitiveKeyWithNull_tMap_1 = false;

										row4HashKey.title = row2.title;

										row4HashKey.hashCodeDirty = true;

										tHash_Lookup_row4.lookup(row4HashKey);

										if (!tHash_Lookup_row4.hasNext()) { // G_TM_M_090

											rejectedInnerJoin_tMap_1 = true;

										} // G_TM_M_090

									} // G_TM_M_020

									if (tHash_Lookup_row4 != null && tHash_Lookup_row4.getCount(row4HashKey) > 1) { // G
																													// 071

										// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row4'
										// and it contains more one result from keys : row4.title = '" +
										// row4HashKey.title + "'");
									} // G 071

									row4Struct row4 = null;

									row4Struct fromLookup_row4 = null;
									row4 = row4Default;

									if (tHash_Lookup_row4 != null && tHash_Lookup_row4.hasNext()) { // G 099

										fromLookup_row4 = tHash_Lookup_row4.next();

									} // G 099

									if (fromLookup_row4 != null) {
										row4 = fromLookup_row4;
									}

									// ###############################
									{ // start of Var scope

										// ###############################
										// # Vars tables

										Var__tMap_1__Struct Var = Var__tMap_1;
										Var.year = TalendDate.getPartOfDate("YEAR", row2.release);
										Var.gainouperte = (row3.revenue - row3.budget);// ###############################
										// ###############################
										// # Output tables

										page1 = null;
										page2 = null;
										page3 = null;

										if (!rejectedInnerJoin_tMap_1) {

// # Output table : 'page1'
											page1_tmp.title = row2.title;
											page1_tmp.budget = row3.budget;
											page1_tmp.revenue = row3.revenue;
											page1_tmp.release = row2.release;
											page1 = page1_tmp;

// # Output table : 'page2'
											page2_tmp.year = Var.year;
											page2_tmp.title = row2.title;
											page2_tmp.budget = row3.budget;
											page2_tmp.revenue = row3.revenue;
											page2 = page2_tmp;

// # Output table : 'page3'
											page3_tmp.title = row2.title;
											page3_tmp.gainouperte = Var.gainouperte;
											page3 = page3_tmp;
										} // closing inner join bracket (2)
// ###############################

									} // end of Var scope

									rejectedInnerJoin_tMap_1 = false;

									tos_count_tMap_1++;

									/**
									 * [tMap_1 main ] stop
									 */

									/**
									 * [tMap_1 process_data_begin ] start
									 */

									currentComponent = "tMap_1";

									/**
									 * [tMap_1 process_data_begin ] stop
									 */
// Start of branch "page1"
									if (page1 != null) {

										/**
										 * [tSortRow_6_SortOut main ] start
										 */

										currentVirtualComponent = "tSortRow_6";

										currentComponent = "tSortRow_6_SortOut";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "page1"

											);
										}

										Comparablepage1Struct arrayRowtSortRow_6_SortOut = new Comparablepage1Struct();

										arrayRowtSortRow_6_SortOut.title = page1.title;
										arrayRowtSortRow_6_SortOut.budget = page1.budget;
										arrayRowtSortRow_6_SortOut.revenue = page1.revenue;
										arrayRowtSortRow_6_SortOut.release = page1.release;
										list_tSortRow_6_SortOut.add(arrayRowtSortRow_6_SortOut);

										tos_count_tSortRow_6_SortOut++;

										/**
										 * [tSortRow_6_SortOut main ] stop
										 */

										/**
										 * [tSortRow_6_SortOut process_data_begin ] start
										 */

										currentVirtualComponent = "tSortRow_6";

										currentComponent = "tSortRow_6_SortOut";

										/**
										 * [tSortRow_6_SortOut process_data_begin ] stop
										 */

										/**
										 * [tSortRow_6_SortOut process_data_end ] start
										 */

										currentVirtualComponent = "tSortRow_6";

										currentComponent = "tSortRow_6_SortOut";

										/**
										 * [tSortRow_6_SortOut process_data_end ] stop
										 */

									} // End of branch "page1"

// Start of branch "page2"
									if (page2 != null) {

										/**
										 * [tSortRow_8_SortOut main ] start
										 */

										currentVirtualComponent = "tSortRow_8";

										currentComponent = "tSortRow_8_SortOut";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "page2"

											);
										}

										Comparablepage2Struct arrayRowtSortRow_8_SortOut = new Comparablepage2Struct();

										arrayRowtSortRow_8_SortOut.year = page2.year;
										arrayRowtSortRow_8_SortOut.title = page2.title;
										arrayRowtSortRow_8_SortOut.budget = page2.budget;
										arrayRowtSortRow_8_SortOut.revenue = page2.revenue;
										list_tSortRow_8_SortOut.add(arrayRowtSortRow_8_SortOut);

										tos_count_tSortRow_8_SortOut++;

										/**
										 * [tSortRow_8_SortOut main ] stop
										 */

										/**
										 * [tSortRow_8_SortOut process_data_begin ] start
										 */

										currentVirtualComponent = "tSortRow_8";

										currentComponent = "tSortRow_8_SortOut";

										/**
										 * [tSortRow_8_SortOut process_data_begin ] stop
										 */

										/**
										 * [tSortRow_8_SortOut process_data_end ] start
										 */

										currentVirtualComponent = "tSortRow_8";

										currentComponent = "tSortRow_8_SortOut";

										/**
										 * [tSortRow_8_SortOut process_data_end ] stop
										 */

									} // End of branch "page2"

// Start of branch "page3"
									if (page3 != null) {

										/**
										 * [tSortRow_9_SortOut main ] start
										 */

										currentVirtualComponent = "tSortRow_9";

										currentComponent = "tSortRow_9_SortOut";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "page3"

											);
										}

										Comparablepage3Struct arrayRowtSortRow_9_SortOut = new Comparablepage3Struct();

										arrayRowtSortRow_9_SortOut.title = page3.title;
										arrayRowtSortRow_9_SortOut.gainouperte = page3.gainouperte;
										list_tSortRow_9_SortOut.add(arrayRowtSortRow_9_SortOut);

										tos_count_tSortRow_9_SortOut++;

										/**
										 * [tSortRow_9_SortOut main ] stop
										 */

										/**
										 * [tSortRow_9_SortOut process_data_begin ] start
										 */

										currentVirtualComponent = "tSortRow_9";

										currentComponent = "tSortRow_9_SortOut";

										/**
										 * [tSortRow_9_SortOut process_data_begin ] stop
										 */

										/**
										 * [tSortRow_9_SortOut process_data_end ] start
										 */

										currentVirtualComponent = "tSortRow_9";

										currentComponent = "tSortRow_9_SortOut";

										/**
										 * [tSortRow_9_SortOut process_data_end ] stop
										 */

									} // End of branch "page3"

									/**
									 * [tMap_1 process_data_end ] start
									 */

									currentComponent = "tMap_1";

									/**
									 * [tMap_1 process_data_end ] stop
									 */

								} // End of branch "row2"

// Start of branch "row5"
								if (row5 != null) {

									/**
									 * [tFileOutputExcel_1 main ] start
									 */

									currentComponent = "tFileOutputExcel_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "row5"

										);
									}

									if (row5.movieID != null) {

//modif start

										columnIndex_tFileOutputExcel_1 = 0;

										jxl.write.WritableCell cell_0_tFileOutputExcel_1 = new jxl.write.Number(
												columnIndex_tFileOutputExcel_1,
												startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
												row5.movieID);
//modif start					
										// If we keep the cell format from the existing cell in sheet

//modif ends							
										writableSheet_tFileOutputExcel_1.addCell(cell_0_tFileOutputExcel_1);
										int currentWith_0_tFileOutputExcel_1 = String
												.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_1).getValue())
												.trim().length();
										currentWith_0_tFileOutputExcel_1 = currentWith_0_tFileOutputExcel_1 > 10 ? 10
												: currentWith_0_tFileOutputExcel_1;
										fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > currentWith_0_tFileOutputExcel_1
												? fitWidth_tFileOutputExcel_1[0]
												: currentWith_0_tFileOutputExcel_1 + 2;
									}

									if (row5.title != null) {

//modif start

										columnIndex_tFileOutputExcel_1 = 1;

										jxl.write.WritableCell cell_1_tFileOutputExcel_1 = new jxl.write.Label(
												columnIndex_tFileOutputExcel_1,
												startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
												row5.title);
//modif start					
										// If we keep the cell format from the existing cell in sheet

//modif ends							
										writableSheet_tFileOutputExcel_1.addCell(cell_1_tFileOutputExcel_1);
										int currentWith_1_tFileOutputExcel_1 = cell_1_tFileOutputExcel_1.getContents()
												.trim().length();
										fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > currentWith_1_tFileOutputExcel_1
												? fitWidth_tFileOutputExcel_1[1]
												: currentWith_1_tFileOutputExcel_1 + 2;
									}

									if (row5.release != null) {

//modif start

										columnIndex_tFileOutputExcel_1 = 2;

										jxl.write.WritableCell cell_2_tFileOutputExcel_1 = new jxl.write.DateTime(
												columnIndex_tFileOutputExcel_1,
												startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
												row5.release, cell_format_release_tFileOutputExcel_1);
//modif start					
										// If we keep the cell format from the existing cell in sheet

//modif ends							
										writableSheet_tFileOutputExcel_1.addCell(cell_2_tFileOutputExcel_1);
										int currentWith_2_tFileOutputExcel_1 = cell_2_tFileOutputExcel_1.getContents()
												.trim().length();
										currentWith_2_tFileOutputExcel_1 = 12;
										fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > currentWith_2_tFileOutputExcel_1
												? fitWidth_tFileOutputExcel_1[2]
												: currentWith_2_tFileOutputExcel_1 + 2;
									}

									if (row5.errorMessage != null) {

//modif start

										columnIndex_tFileOutputExcel_1 = 3;

										jxl.write.WritableCell cell_3_tFileOutputExcel_1 = new jxl.write.Label(
												columnIndex_tFileOutputExcel_1,
												startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
												row5.errorMessage);
//modif start					
										// If we keep the cell format from the existing cell in sheet

//modif ends							
										writableSheet_tFileOutputExcel_1.addCell(cell_3_tFileOutputExcel_1);
										int currentWith_3_tFileOutputExcel_1 = cell_3_tFileOutputExcel_1.getContents()
												.trim().length();
										fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > currentWith_3_tFileOutputExcel_1
												? fitWidth_tFileOutputExcel_1[3]
												: currentWith_3_tFileOutputExcel_1 + 2;
									}

									nb_line_tFileOutputExcel_1++;

									tos_count_tFileOutputExcel_1++;

									/**
									 * [tFileOutputExcel_1 main ] stop
									 */

									/**
									 * [tFileOutputExcel_1 process_data_begin ] start
									 */

									currentComponent = "tFileOutputExcel_1";

									/**
									 * [tFileOutputExcel_1 process_data_begin ] stop
									 */

									/**
									 * [tFileOutputExcel_1 process_data_end ] start
									 */

									currentComponent = "tFileOutputExcel_1";

									/**
									 * [tFileOutputExcel_1 process_data_end ] stop
									 */

								} // End of branch "row5"

								/**
								 * [tFilterRow_1 process_data_end ] start
								 */

								currentComponent = "tFilterRow_1";

								/**
								 * [tFilterRow_1 process_data_end ] stop
								 */

								/**
								 * [tFilterColumns_1 process_data_end ] start
								 */

								currentComponent = "tFilterColumns_1";

								/**
								 * [tFilterColumns_1 process_data_end ] stop
								 */

							} // End of branch "row1"

							/**
							 * [tFileInputExcel_1 process_data_end ] start
							 */

							currentComponent = "tFileInputExcel_1";

							/**
							 * [tFileInputExcel_1 process_data_end ] stop
							 */

							/**
							 * [tFileInputExcel_1 end ] start
							 */

							currentComponent = "tFileInputExcel_1";

						}

						globalMap.put("tFileInputExcel_1_NB_LINE", nb_line_tFileInputExcel_1);

					}

				} finally {

					if (!(source_tFileInputExcel_1 instanceof java.io.InputStream)) {
						workbook_tFileInputExcel_1.close();
					}

				}

				ok_Hash.put("tFileInputExcel_1", true);
				end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileInputExcel_1 end ] stop
				 */

				/**
				 * [tFilterColumns_1 end ] start
				 */

				currentComponent = "tFilterColumns_1";

				globalMap.put("tFilterColumns_1_NB_LINE", nb_line_tFilterColumns_1);
				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tFilterColumns_1", true);
				end_Hash.put("tFilterColumns_1", System.currentTimeMillis());

				/**
				 * [tFilterColumns_1 end ] stop
				 */

				/**
				 * [tFilterRow_1 end ] start
				 */

				currentComponent = "tFilterRow_1";

				globalMap.put("tFilterRow_1_NB_LINE", nb_line_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_OK", nb_line_ok_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_REJECT", nb_line_reject_tFilterRow_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row21");
				}

				ok_Hash.put("tFilterRow_1", true);
				end_Hash.put("tFilterRow_1", System.currentTimeMillis());

				/**
				 * [tFilterRow_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row3 != null) {
					tHash_Lookup_row3.endGet();
				}
				globalMap.remove("tHash_Lookup_row3");

				if (tHash_Lookup_row4 != null) {
					tHash_Lookup_row4.endGet();
				}
				globalMap.remove("tHash_Lookup_row4");

// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tSortRow_6_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_6";

				currentComponent = "tSortRow_6_SortOut";

				page1Struct[] array_tSortRow_6_SortOut = list_tSortRow_6_SortOut.toArray(new Comparablepage1Struct[0]);

				java.util.Arrays.sort(array_tSortRow_6_SortOut);

				globalMap.put("tSortRow_6", array_tSortRow_6_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "page1");
				}

				ok_Hash.put("tSortRow_6_SortOut", true);
				end_Hash.put("tSortRow_6_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_6_SortOut end ] stop
				 */

				/**
				 * [tSortRow_7_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_7_SortOut", false);
				start_Hash.put("tSortRow_7_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_7";

				currentComponent = "tSortRow_7_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row11");
				}

				int tos_count_tSortRow_7_SortOut = 0;

				class Comparablerow11Struct extends row11Struct implements Comparable<Comparablerow11Struct> {

					public int compareTo(Comparablerow11Struct other) {

						if (this.title == null && other.title != null) {
							return -1;

						} else if (this.title != null && other.title == null) {
							return 1;

						} else if (this.title != null && other.title != null) {
							if (!this.title.equals(other.title)) {
								return this.title.compareTo(other.title);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow11Struct> list_tSortRow_7_SortOut = new java.util.ArrayList<Comparablerow11Struct>();

				/**
				 * [tSortRow_7_SortOut begin ] stop
				 */

				/**
				 * [tSortRow_6_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_6_SortIn", false);
				start_Hash.put("tSortRow_6_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_6";

				currentComponent = "tSortRow_6_SortIn";

				int tos_count_tSortRow_6_SortIn = 0;

				page1Struct[] array_tSortRow_6_SortIn = (page1Struct[]) globalMap.remove("tSortRow_6");

				int nb_line_tSortRow_6_SortIn = 0;

				page1Struct current_tSortRow_6_SortIn = null;

				for (int i_tSortRow_6_SortIn = 0; i_tSortRow_6_SortIn < array_tSortRow_6_SortIn.length; i_tSortRow_6_SortIn++) {
					current_tSortRow_6_SortIn = array_tSortRow_6_SortIn[i_tSortRow_6_SortIn];
					row11.title = current_tSortRow_6_SortIn.title;
					row11.budget = current_tSortRow_6_SortIn.budget;
					row11.revenue = current_tSortRow_6_SortIn.revenue;
					row11.release = current_tSortRow_6_SortIn.release;
					// increase number of line sorted
					nb_line_tSortRow_6_SortIn++;

					/**
					 * [tSortRow_6_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_6_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_6";

					currentComponent = "tSortRow_6_SortIn";

					tos_count_tSortRow_6_SortIn++;

					/**
					 * [tSortRow_6_SortIn main ] stop
					 */

					/**
					 * [tSortRow_6_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_6";

					currentComponent = "tSortRow_6_SortIn";

					/**
					 * [tSortRow_6_SortIn process_data_begin ] stop
					 */

					/**
					 * [tSortRow_7_SortOut main ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortOut";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row11"

						);
					}

					Comparablerow11Struct arrayRowtSortRow_7_SortOut = new Comparablerow11Struct();

					arrayRowtSortRow_7_SortOut.title = row11.title;
					arrayRowtSortRow_7_SortOut.budget = row11.budget;
					arrayRowtSortRow_7_SortOut.revenue = row11.revenue;
					arrayRowtSortRow_7_SortOut.release = row11.release;
					list_tSortRow_7_SortOut.add(arrayRowtSortRow_7_SortOut);

					tos_count_tSortRow_7_SortOut++;

					/**
					 * [tSortRow_7_SortOut main ] stop
					 */

					/**
					 * [tSortRow_7_SortOut process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortOut";

					/**
					 * [tSortRow_7_SortOut process_data_begin ] stop
					 */

					/**
					 * [tSortRow_7_SortOut process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortOut";

					/**
					 * [tSortRow_7_SortOut process_data_end ] stop
					 */

					/**
					 * [tSortRow_6_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_6";

					currentComponent = "tSortRow_6_SortIn";

					/**
					 * [tSortRow_6_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_6_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_6";

					currentComponent = "tSortRow_6_SortIn";

				}

				globalMap.put("tSortRow_6_SortIn_NB_LINE", nb_line_tSortRow_6_SortIn);

				ok_Hash.put("tSortRow_6_SortIn", true);
				end_Hash.put("tSortRow_6_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_6_SortIn end ] stop
				 */

				/**
				 * [tSortRow_7_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_7";

				currentComponent = "tSortRow_7_SortOut";

				row11Struct[] array_tSortRow_7_SortOut = list_tSortRow_7_SortOut.toArray(new Comparablerow11Struct[0]);

				java.util.Arrays.sort(array_tSortRow_7_SortOut);

				globalMap.put("tSortRow_7", array_tSortRow_7_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row11");
				}

				ok_Hash.put("tSortRow_7_SortOut", true);
				end_Hash.put("tSortRow_7_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_7_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_3 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_3", false);
				start_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row12");
				}

				int tos_count_tFileOutputExcel_3 = 0;

				int columnIndex_tFileOutputExcel_3 = 0;
				boolean headerIsInserted_tFileOutputExcel_3 = false;

				int nb_line_tFileOutputExcel_3 = 0;

				String fileName_tFileOutputExcel_3 = "C:/Program Files/TOS_DI-8.0.1/studio/workspace/fichierFinal.xls";
				java.io.File file_tFileOutputExcel_3 = new java.io.File(fileName_tFileOutputExcel_3);
				boolean isFileGenerated_tFileOutputExcel_3 = true;
				if (file_tFileOutputExcel_3.exists()) {
					isFileGenerated_tFileOutputExcel_3 = false;
				}
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_3 = file_tFileOutputExcel_3.getParentFile();
				if (parentFile_tFileOutputExcel_3 != null && !parentFile_tFileOutputExcel_3.exists()) {

					parentFile_tFileOutputExcel_3.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_3 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_3 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_3 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_3.setEncoding("ISO-8859-15");
				if (file_tFileOutputExcel_3.exists()) {
					jxl.Workbook workbook_tFileOutputExcel_3 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_3,
							workbookSettings_tFileOutputExcel_3);
					workbookSettings_tFileOutputExcel_3.setWriteAccess(null);
					writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(
									new java.io.FileOutputStream(file_tFileOutputExcel_3, false)),
							workbook_tFileOutputExcel_3, true, workbookSettings_tFileOutputExcel_3);
				} else {
					writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_3)),
							true, workbookSettings_tFileOutputExcel_3);
				}

				writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_3 == null) {
					writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
				}

				else {

					String[] sheetNames_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheetNames();
					for (int i = 0; i < sheetNames_tFileOutputExcel_3.length; i++) {
						if (sheetNames_tFileOutputExcel_3[i].equals("Sheet1")) {
							writeableWorkbook_tFileOutputExcel_3.removeSheet(i);
							break;
						}
					}

					writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_3 = new int[4];
				for (int i_tFileOutputExcel_3 = 0; i_tFileOutputExcel_3 < 4; i_tFileOutputExcel_3++) {
					int fitCellViewSize_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3
							.getColumnView(i_tFileOutputExcel_3).getSize();
					fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3] = fitCellViewSize_tFileOutputExcel_3 / 256;
					if (fitCellViewSize_tFileOutputExcel_3 % 256 != 0) {
						fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_release_tFileOutputExcel_3 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_3 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_3, "title"));
					// modif end
					fitWidth_tFileOutputExcel_3[0] = fitWidth_tFileOutputExcel_3[0] > 5 ? fitWidth_tFileOutputExcel_3[0]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_3, "budget"));
					// modif end
					fitWidth_tFileOutputExcel_3[1] = fitWidth_tFileOutputExcel_3[1] > 6 ? fitWidth_tFileOutputExcel_3[1]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_3, "revenue"));
					// modif end
					fitWidth_tFileOutputExcel_3[2] = fitWidth_tFileOutputExcel_3[2] > 7 ? fitWidth_tFileOutputExcel_3[2]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_3, "release"));
					// modif end
					fitWidth_tFileOutputExcel_3[3] = fitWidth_tFileOutputExcel_3[3] > 7 ? fitWidth_tFileOutputExcel_3[3]
							: 7;
					nb_line_tFileOutputExcel_3++;
					headerIsInserted_tFileOutputExcel_3 = true;
				}

				/**
				 * [tFileOutputExcel_3 begin ] stop
				 */

				/**
				 * [tSortRow_7_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_7_SortIn", false);
				start_Hash.put("tSortRow_7_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_7";

				currentComponent = "tSortRow_7_SortIn";

				int tos_count_tSortRow_7_SortIn = 0;

				row11Struct[] array_tSortRow_7_SortIn = (row11Struct[]) globalMap.remove("tSortRow_7");

				int nb_line_tSortRow_7_SortIn = 0;

				row11Struct current_tSortRow_7_SortIn = null;

				for (int i_tSortRow_7_SortIn = 0; i_tSortRow_7_SortIn < array_tSortRow_7_SortIn.length; i_tSortRow_7_SortIn++) {
					current_tSortRow_7_SortIn = array_tSortRow_7_SortIn[i_tSortRow_7_SortIn];
					row12.title = current_tSortRow_7_SortIn.title;
					row12.budget = current_tSortRow_7_SortIn.budget;
					row12.revenue = current_tSortRow_7_SortIn.revenue;
					row12.release = current_tSortRow_7_SortIn.release;
					// increase number of line sorted
					nb_line_tSortRow_7_SortIn++;

					/**
					 * [tSortRow_7_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_7_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortIn";

					tos_count_tSortRow_7_SortIn++;

					/**
					 * [tSortRow_7_SortIn main ] stop
					 */

					/**
					 * [tSortRow_7_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortIn";

					/**
					 * [tSortRow_7_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_3 main ] start
					 */

					currentComponent = "tFileOutputExcel_3";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row12"

						);
					}

					if (row12.title != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_3 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row12.title);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_0_tFileOutputExcel_3);
						int currentWith_0_tFileOutputExcel_3 = cell_0_tFileOutputExcel_3.getContents().trim().length();
						fitWidth_tFileOutputExcel_3[0] = fitWidth_tFileOutputExcel_3[0] > currentWith_0_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[0]
								: currentWith_0_tFileOutputExcel_3 + 2;
					}

					if (row12.budget != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_3 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row12.budget);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_1_tFileOutputExcel_3);
						int currentWith_1_tFileOutputExcel_3 = String
								.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_3).getValue()).trim().length();
						currentWith_1_tFileOutputExcel_3 = currentWith_1_tFileOutputExcel_3 > 10 ? 10
								: currentWith_1_tFileOutputExcel_3;
						fitWidth_tFileOutputExcel_3[1] = fitWidth_tFileOutputExcel_3[1] > currentWith_1_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[1]
								: currentWith_1_tFileOutputExcel_3 + 2;
					}

					if (row12.revenue != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_3 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row12.revenue);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_2_tFileOutputExcel_3);
						int currentWith_2_tFileOutputExcel_3 = String
								.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_3).getValue()).trim().length();
						currentWith_2_tFileOutputExcel_3 = currentWith_2_tFileOutputExcel_3 > 10 ? 10
								: currentWith_2_tFileOutputExcel_3;
						fitWidth_tFileOutputExcel_3[2] = fitWidth_tFileOutputExcel_3[2] > currentWith_2_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[2]
								: currentWith_2_tFileOutputExcel_3 + 2;
					}

					if (row12.release != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 3;

						jxl.write.WritableCell cell_3_tFileOutputExcel_3 = new jxl.write.DateTime(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row12.release, cell_format_release_tFileOutputExcel_3);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_3_tFileOutputExcel_3);
						int currentWith_3_tFileOutputExcel_3 = cell_3_tFileOutputExcel_3.getContents().trim().length();
						currentWith_3_tFileOutputExcel_3 = 12;
						fitWidth_tFileOutputExcel_3[3] = fitWidth_tFileOutputExcel_3[3] > currentWith_3_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[3]
								: currentWith_3_tFileOutputExcel_3 + 2;
					}

					nb_line_tFileOutputExcel_3++;

					tos_count_tFileOutputExcel_3++;

					/**
					 * [tFileOutputExcel_3 main ] stop
					 */

					/**
					 * [tFileOutputExcel_3 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_3";

					/**
					 * [tFileOutputExcel_3 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_3 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_3";

					/**
					 * [tFileOutputExcel_3 process_data_end ] stop
					 */

					/**
					 * [tSortRow_7_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortIn";

					/**
					 * [tSortRow_7_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_7_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_7";

					currentComponent = "tSortRow_7_SortIn";

				}

				globalMap.put("tSortRow_7_SortIn_NB_LINE", nb_line_tSortRow_7_SortIn);

				ok_Hash.put("tSortRow_7_SortIn", true);
				end_Hash.put("tSortRow_7_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_7_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_3 end ] start
				 */

				currentComponent = "tFileOutputExcel_3";

				writeableWorkbook_tFileOutputExcel_3.write();
				writeableWorkbook_tFileOutputExcel_3.close();
				if (headerIsInserted_tFileOutputExcel_3 && nb_line_tFileOutputExcel_3 > 0) {
					nb_line_tFileOutputExcel_3 = nb_line_tFileOutputExcel_3 - 1;
				}
				globalMap.put("tFileOutputExcel_3_NB_LINE", nb_line_tFileOutputExcel_3);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row12");
				}

				ok_Hash.put("tFileOutputExcel_3", true);
				end_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_3 end ] stop
				 */

				/**
				 * [tSortRow_8_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_8";

				currentComponent = "tSortRow_8_SortOut";

				page2Struct[] array_tSortRow_8_SortOut = list_tSortRow_8_SortOut.toArray(new Comparablepage2Struct[0]);

				java.util.Arrays.sort(array_tSortRow_8_SortOut);

				globalMap.put("tSortRow_8", array_tSortRow_8_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "page2");
				}

				ok_Hash.put("tSortRow_8_SortOut", true);
				end_Hash.put("tSortRow_8_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_8_SortOut end ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT begin ] start
				 */

				ok_Hash.put("tAggregateRow_1_AGGOUT", false);
				start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row13");
				}

				int tos_count_tAggregateRow_1_AGGOUT = 0;

// ------------ Seems it is not used

				java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap();

// ------------

				class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

					public double sd(Double[] data) {
						final int n = data.length;
						if (n < 2) {
							return Double.NaN;
						}
						double d1 = 0d;
						double d2 = 0d;

						for (int i = 0; i < data.length; i++) {
							d1 += (data[i] * data[i]);
							d2 += data[i];
						}

						return Math.sqrt((n * d1 - d2 * d2) / n / (n - 1));
					}

					public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
						byte r = (byte) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'short/Short'", "'byte/Byte'"));
						}
					}

					public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
						short r = (short) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'int/Integer'", "'short/Short'"));
						}
					}

					public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
						int r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'long/Long'", "'int/Integer'"));
						}
					}

					public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
						long r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'long/Long'"));
						}
					}

					public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							float minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b),
										"'double' or 'BigDecimal'", "'float/Float'"));
							}
						}

						if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE)
								|| ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'double' or 'BigDecimal'", "'float/Float'"));
						}
					}

					public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
						return "Type overflow when adding " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

					private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
						return "The double precision is unsufficient to add the value " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

				} // G_OutBegin_AggR_144

				UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

				class AggCountDistinctValuesStruct_title_tAggregateRow_1 { // G_OutBegin_AggR_1100

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					int year;
					String title;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + (int) this.year;

							result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final AggCountDistinctValuesStruct_title_tAggregateRow_1 other = (AggCountDistinctValuesStruct_title_tAggregateRow_1) obj;

						if (this.year != other.year)
							return false;

						if (this.title == null) {
							if (other.title != null)
								return false;
						} else if (!this.title.equals(other.title))
							return false;

						return true;
					}

				} // G_OutBegin_AggR_1100

				class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					int year;
					Long budget_sum;
					java.util.Set<AggCountDistinctValuesStruct_title_tAggregateRow_1> distinctValues_countYear = new java.util.HashSet<AggCountDistinctValuesStruct_title_tAggregateRow_1>();

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + (int) this.year;

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;

						if (this.year != other.year)
							return false;

						return true;
					}

				} // G_OutBegin_AggR_100

				AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
				AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
				java.util.Map<AggOperationStruct_tAggregateRow_1, AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1, AggOperationStruct_tAggregateRow_1>();

				/**
				 * [tAggregateRow_1_AGGOUT begin ] stop
				 */

				/**
				 * [tSortRow_8_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_8_SortIn", false);
				start_Hash.put("tSortRow_8_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_8";

				currentComponent = "tSortRow_8_SortIn";

				int tos_count_tSortRow_8_SortIn = 0;

				page2Struct[] array_tSortRow_8_SortIn = (page2Struct[]) globalMap.remove("tSortRow_8");

				int nb_line_tSortRow_8_SortIn = 0;

				page2Struct current_tSortRow_8_SortIn = null;

				for (int i_tSortRow_8_SortIn = 0; i_tSortRow_8_SortIn < array_tSortRow_8_SortIn.length; i_tSortRow_8_SortIn++) {
					current_tSortRow_8_SortIn = array_tSortRow_8_SortIn[i_tSortRow_8_SortIn];
					row13.year = current_tSortRow_8_SortIn.year;
					row13.title = current_tSortRow_8_SortIn.title;
					row13.budget = current_tSortRow_8_SortIn.budget;
					row13.revenue = current_tSortRow_8_SortIn.revenue;
					// increase number of line sorted
					nb_line_tSortRow_8_SortIn++;

					/**
					 * [tSortRow_8_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_8_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_8";

					currentComponent = "tSortRow_8_SortIn";

					tos_count_tSortRow_8_SortIn++;

					/**
					 * [tSortRow_8_SortIn main ] stop
					 */

					/**
					 * [tSortRow_8_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_8";

					currentComponent = "tSortRow_8_SortIn";

					/**
					 * [tSortRow_8_SortIn process_data_begin ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGOUT main ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGOUT";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row13"

						);
					}

					operation_finder_tAggregateRow_1.year = row13.year;

					operation_finder_tAggregateRow_1.hashCodeDirty = true;

					operation_result_tAggregateRow_1 = hash_tAggregateRow_1.get(operation_finder_tAggregateRow_1);

					if (operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

						operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

						operation_result_tAggregateRow_1.year = operation_finder_tAggregateRow_1.year;

						hash_tAggregateRow_1.put(operation_result_tAggregateRow_1, operation_result_tAggregateRow_1);

					} // G_OutMain_AggR_001

					if (operation_result_tAggregateRow_1.budget_sum == null) {
						operation_result_tAggregateRow_1.budget_sum = (long) 0;
					}

					if (row13.budget != null)
						operation_result_tAggregateRow_1.budget_sum += row13.budget;

					AggCountDistinctValuesStruct_title_tAggregateRow_1 countDistinctValues_countYear_tAggregateRow_1 = new AggCountDistinctValuesStruct_title_tAggregateRow_1();

					countDistinctValues_countYear_tAggregateRow_1.year = row13.year;

					countDistinctValues_countYear_tAggregateRow_1.title = row13.title;
					operation_result_tAggregateRow_1.distinctValues_countYear
							.add(countDistinctValues_countYear_tAggregateRow_1);

					tos_count_tAggregateRow_1_AGGOUT++;

					/**
					 * [tAggregateRow_1_AGGOUT main ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGOUT process_data_begin ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGOUT";

					/**
					 * [tAggregateRow_1_AGGOUT process_data_begin ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGOUT process_data_end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGOUT";

					/**
					 * [tAggregateRow_1_AGGOUT process_data_end ] stop
					 */

					/**
					 * [tSortRow_8_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_8";

					currentComponent = "tSortRow_8_SortIn";

					/**
					 * [tSortRow_8_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_8_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_8";

					currentComponent = "tSortRow_8_SortIn";

				}

				globalMap.put("tSortRow_8_SortIn_NB_LINE", nb_line_tSortRow_8_SortIn);

				ok_Hash.put("tSortRow_8_SortIn", true);
				end_Hash.put("tSortRow_8_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_8_SortIn end ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT end ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row13");
				}

				ok_Hash.put("tAggregateRow_1_AGGOUT", true);
				end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());

				/**
				 * [tAggregateRow_1_AGGOUT end ] stop
				 */

				/**
				 * [tFileOutputExcel_5 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_5", false);
				start_Hash.put("tFileOutputExcel_5", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_5";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row14");
				}

				int tos_count_tFileOutputExcel_5 = 0;

				int columnIndex_tFileOutputExcel_5 = 0;
				boolean headerIsInserted_tFileOutputExcel_5 = false;

				int nb_line_tFileOutputExcel_5 = 0;

				String fileName_tFileOutputExcel_5 = "C:/Program Files/TOS_DI-8.0.1/studio/workspace/fichierfinal.xls";
				java.io.File file_tFileOutputExcel_5 = new java.io.File(fileName_tFileOutputExcel_5);
				boolean isFileGenerated_tFileOutputExcel_5 = true;
				if (file_tFileOutputExcel_5.exists()) {
					isFileGenerated_tFileOutputExcel_5 = false;
				}
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_5 = file_tFileOutputExcel_5.getParentFile();
				if (parentFile_tFileOutputExcel_5 != null && !parentFile_tFileOutputExcel_5.exists()) {

					parentFile_tFileOutputExcel_5.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_5 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_5 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_5 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_5.setEncoding("ISO-8859-15");
				if (file_tFileOutputExcel_5.exists()) {
					jxl.Workbook workbook_tFileOutputExcel_5 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_5,
							workbookSettings_tFileOutputExcel_5);
					workbookSettings_tFileOutputExcel_5.setWriteAccess(null);
					writeableWorkbook_tFileOutputExcel_5 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(
									new java.io.FileOutputStream(file_tFileOutputExcel_5, false)),
							workbook_tFileOutputExcel_5, true, workbookSettings_tFileOutputExcel_5);
				} else {
					writeableWorkbook_tFileOutputExcel_5 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_5)),
							true, workbookSettings_tFileOutputExcel_5);
				}

				writableSheet_tFileOutputExcel_5 = writeableWorkbook_tFileOutputExcel_5.getSheet("Sheet2");
				if (writableSheet_tFileOutputExcel_5 == null) {
					writableSheet_tFileOutputExcel_5 = writeableWorkbook_tFileOutputExcel_5.createSheet("Sheet2",
							writeableWorkbook_tFileOutputExcel_5.getNumberOfSheets());
				}

				else {

					String[] sheetNames_tFileOutputExcel_5 = writeableWorkbook_tFileOutputExcel_5.getSheetNames();
					for (int i = 0; i < sheetNames_tFileOutputExcel_5.length; i++) {
						if (sheetNames_tFileOutputExcel_5[i].equals("Sheet2")) {
							writeableWorkbook_tFileOutputExcel_5.removeSheet(i);
							break;
						}
					}

					writableSheet_tFileOutputExcel_5 = writeableWorkbook_tFileOutputExcel_5.createSheet("Sheet2",
							writeableWorkbook_tFileOutputExcel_5.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_5 = writableSheet_tFileOutputExcel_5.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_5 = new int[3];
				for (int i_tFileOutputExcel_5 = 0; i_tFileOutputExcel_5 < 3; i_tFileOutputExcel_5++) {
					int fitCellViewSize_tFileOutputExcel_5 = writableSheet_tFileOutputExcel_5
							.getColumnView(i_tFileOutputExcel_5).getSize();
					fitWidth_tFileOutputExcel_5[i_tFileOutputExcel_5] = fitCellViewSize_tFileOutputExcel_5 / 256;
					if (fitCellViewSize_tFileOutputExcel_5 % 256 != 0) {
						fitWidth_tFileOutputExcel_5[i_tFileOutputExcel_5] += 1;
					}
				}

				if (startRowNum_tFileOutputExcel_5 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_5, "year"));
					// modif end
					fitWidth_tFileOutputExcel_5[0] = fitWidth_tFileOutputExcel_5[0] > 4 ? fitWidth_tFileOutputExcel_5[0]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_5, "budget"));
					// modif end
					fitWidth_tFileOutputExcel_5[1] = fitWidth_tFileOutputExcel_5[1] > 6 ? fitWidth_tFileOutputExcel_5[1]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_5, "countYear"));
					// modif end
					fitWidth_tFileOutputExcel_5[2] = fitWidth_tFileOutputExcel_5[2] > 9 ? fitWidth_tFileOutputExcel_5[2]
							: 9;
					nb_line_tFileOutputExcel_5++;
					headerIsInserted_tFileOutputExcel_5 = true;
				}

				/**
				 * [tFileOutputExcel_5 begin ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGIN begin ] start
				 */

				ok_Hash.put("tAggregateRow_1_AGGIN", false);
				start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGIN";

				int tos_count_tAggregateRow_1_AGGIN = 0;

				java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1
						.values();

				globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

				for (AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600

					/**
					 * [tAggregateRow_1_AGGIN begin ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN main ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					row14.year = aggregated_row_tAggregateRow_1.year;
					row14.budget = aggregated_row_tAggregateRow_1.budget_sum;
					row14.countYear = (int) aggregated_row_tAggregateRow_1.distinctValues_countYear.size();

					tos_count_tAggregateRow_1_AGGIN++;

					/**
					 * [tAggregateRow_1_AGGIN main ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN process_data_begin ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					/**
					 * [tAggregateRow_1_AGGIN process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_5 main ] start
					 */

					currentComponent = "tFileOutputExcel_5";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row14"

						);
					}

//modif start

					columnIndex_tFileOutputExcel_5 = 0;

					jxl.write.WritableCell cell_0_tFileOutputExcel_5 = new jxl.write.Number(
							columnIndex_tFileOutputExcel_5, startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
							row14.year);
//modif start					
					// If we keep the cell format from the existing cell in sheet

//modif ends							
					writableSheet_tFileOutputExcel_5.addCell(cell_0_tFileOutputExcel_5);
					int currentWith_0_tFileOutputExcel_5 = String
							.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_5).getValue()).trim().length();
					currentWith_0_tFileOutputExcel_5 = currentWith_0_tFileOutputExcel_5 > 10 ? 10
							: currentWith_0_tFileOutputExcel_5;
					fitWidth_tFileOutputExcel_5[0] = fitWidth_tFileOutputExcel_5[0] > currentWith_0_tFileOutputExcel_5
							? fitWidth_tFileOutputExcel_5[0]
							: currentWith_0_tFileOutputExcel_5 + 2;

					if (row14.budget != null) {

//modif start

						columnIndex_tFileOutputExcel_5 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_5 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_5,
								startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
								row14.budget);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_5.addCell(cell_1_tFileOutputExcel_5);
						int currentWith_1_tFileOutputExcel_5 = String
								.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_5).getValue()).trim().length();
						currentWith_1_tFileOutputExcel_5 = currentWith_1_tFileOutputExcel_5 > 10 ? 10
								: currentWith_1_tFileOutputExcel_5;
						fitWidth_tFileOutputExcel_5[1] = fitWidth_tFileOutputExcel_5[1] > currentWith_1_tFileOutputExcel_5
								? fitWidth_tFileOutputExcel_5[1]
								: currentWith_1_tFileOutputExcel_5 + 2;
					}

					if (row14.countYear != null) {

//modif start

						columnIndex_tFileOutputExcel_5 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_5 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_5,
								startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
								row14.countYear);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_5.addCell(cell_2_tFileOutputExcel_5);
						int currentWith_2_tFileOutputExcel_5 = String
								.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_5).getValue()).trim().length();
						currentWith_2_tFileOutputExcel_5 = currentWith_2_tFileOutputExcel_5 > 10 ? 10
								: currentWith_2_tFileOutputExcel_5;
						fitWidth_tFileOutputExcel_5[2] = fitWidth_tFileOutputExcel_5[2] > currentWith_2_tFileOutputExcel_5
								? fitWidth_tFileOutputExcel_5[2]
								: currentWith_2_tFileOutputExcel_5 + 2;
					}

					nb_line_tFileOutputExcel_5++;

					tos_count_tFileOutputExcel_5++;

					/**
					 * [tFileOutputExcel_5 main ] stop
					 */

					/**
					 * [tFileOutputExcel_5 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_5";

					/**
					 * [tFileOutputExcel_5 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_5 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_5";

					/**
					 * [tFileOutputExcel_5 process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN process_data_end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					/**
					 * [tAggregateRow_1_AGGIN process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

				} // G_AggR_600

				ok_Hash.put("tAggregateRow_1_AGGIN", true);
				end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());

				/**
				 * [tAggregateRow_1_AGGIN end ] stop
				 */

				/**
				 * [tFileOutputExcel_5 end ] start
				 */

				currentComponent = "tFileOutputExcel_5";

				writeableWorkbook_tFileOutputExcel_5.write();
				writeableWorkbook_tFileOutputExcel_5.close();
				if (headerIsInserted_tFileOutputExcel_5 && nb_line_tFileOutputExcel_5 > 0) {
					nb_line_tFileOutputExcel_5 = nb_line_tFileOutputExcel_5 - 1;
				}
				globalMap.put("tFileOutputExcel_5_NB_LINE", nb_line_tFileOutputExcel_5);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row14");
				}

				ok_Hash.put("tFileOutputExcel_5", true);
				end_Hash.put("tFileOutputExcel_5", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_5 end ] stop
				 */

				/**
				 * [tSortRow_9_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_9";

				currentComponent = "tSortRow_9_SortOut";

				page3Struct[] array_tSortRow_9_SortOut = list_tSortRow_9_SortOut.toArray(new Comparablepage3Struct[0]);

				java.util.Arrays.sort(array_tSortRow_9_SortOut);

				globalMap.put("tSortRow_9", array_tSortRow_9_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "page3");
				}

				ok_Hash.put("tSortRow_9_SortOut", true);
				end_Hash.put("tSortRow_9_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_9_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_6 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_6", false);
				start_Hash.put("tFileOutputExcel_6", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row15");
				}

				int tos_count_tFileOutputExcel_6 = 0;

				int columnIndex_tFileOutputExcel_6 = 0;
				boolean headerIsInserted_tFileOutputExcel_6 = false;

				int nb_line_tFileOutputExcel_6 = 0;

				String fileName_tFileOutputExcel_6 = "C:/Program Files/TOS_DI-8.0.1/studio/workspace/fichierfinal.xls";
				java.io.File file_tFileOutputExcel_6 = new java.io.File(fileName_tFileOutputExcel_6);
				boolean isFileGenerated_tFileOutputExcel_6 = true;
				if (file_tFileOutputExcel_6.exists()) {
					isFileGenerated_tFileOutputExcel_6 = false;
				}
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_6 = file_tFileOutputExcel_6.getParentFile();
				if (parentFile_tFileOutputExcel_6 != null && !parentFile_tFileOutputExcel_6.exists()) {

					parentFile_tFileOutputExcel_6.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_6 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_6 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_6 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_6.setEncoding("ISO-8859-15");
				if (file_tFileOutputExcel_6.exists()) {
					jxl.Workbook workbook_tFileOutputExcel_6 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_6,
							workbookSettings_tFileOutputExcel_6);
					workbookSettings_tFileOutputExcel_6.setWriteAccess(null);
					writeableWorkbook_tFileOutputExcel_6 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(
									new java.io.FileOutputStream(file_tFileOutputExcel_6, false)),
							workbook_tFileOutputExcel_6, true, workbookSettings_tFileOutputExcel_6);
				} else {
					writeableWorkbook_tFileOutputExcel_6 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_6)),
							true, workbookSettings_tFileOutputExcel_6);
				}

				writableSheet_tFileOutputExcel_6 = writeableWorkbook_tFileOutputExcel_6.getSheet("Sheet3");
				if (writableSheet_tFileOutputExcel_6 == null) {
					writableSheet_tFileOutputExcel_6 = writeableWorkbook_tFileOutputExcel_6.createSheet("Sheet3",
							writeableWorkbook_tFileOutputExcel_6.getNumberOfSheets());
				}

				else {

					String[] sheetNames_tFileOutputExcel_6 = writeableWorkbook_tFileOutputExcel_6.getSheetNames();
					for (int i = 0; i < sheetNames_tFileOutputExcel_6.length; i++) {
						if (sheetNames_tFileOutputExcel_6[i].equals("Sheet3")) {
							writeableWorkbook_tFileOutputExcel_6.removeSheet(i);
							break;
						}
					}

					writableSheet_tFileOutputExcel_6 = writeableWorkbook_tFileOutputExcel_6.createSheet("Sheet3",
							writeableWorkbook_tFileOutputExcel_6.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_6 = writableSheet_tFileOutputExcel_6.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_6 = new int[2];
				for (int i_tFileOutputExcel_6 = 0; i_tFileOutputExcel_6 < 2; i_tFileOutputExcel_6++) {
					int fitCellViewSize_tFileOutputExcel_6 = writableSheet_tFileOutputExcel_6
							.getColumnView(i_tFileOutputExcel_6).getSize();
					fitWidth_tFileOutputExcel_6[i_tFileOutputExcel_6] = fitCellViewSize_tFileOutputExcel_6 / 256;
					if (fitCellViewSize_tFileOutputExcel_6 % 256 != 0) {
						fitWidth_tFileOutputExcel_6[i_tFileOutputExcel_6] += 1;
					}
				}

				if (startRowNum_tFileOutputExcel_6 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_6
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_6, "title"));
					// modif end
					fitWidth_tFileOutputExcel_6[0] = fitWidth_tFileOutputExcel_6[0] > 5 ? fitWidth_tFileOutputExcel_6[0]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_6
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_6, "gainouperte"));
					// modif end
					fitWidth_tFileOutputExcel_6[1] = fitWidth_tFileOutputExcel_6[1] > 11
							? fitWidth_tFileOutputExcel_6[1]
							: 11;
					nb_line_tFileOutputExcel_6++;
					headerIsInserted_tFileOutputExcel_6 = true;
				}

				/**
				 * [tFileOutputExcel_6 begin ] stop
				 */

				/**
				 * [tSortRow_9_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_9_SortIn", false);
				start_Hash.put("tSortRow_9_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_9";

				currentComponent = "tSortRow_9_SortIn";

				int tos_count_tSortRow_9_SortIn = 0;

				page3Struct[] array_tSortRow_9_SortIn = (page3Struct[]) globalMap.remove("tSortRow_9");

				int nb_line_tSortRow_9_SortIn = 0;

				page3Struct current_tSortRow_9_SortIn = null;

				for (int i_tSortRow_9_SortIn = 0; i_tSortRow_9_SortIn < array_tSortRow_9_SortIn.length; i_tSortRow_9_SortIn++) {
					current_tSortRow_9_SortIn = array_tSortRow_9_SortIn[i_tSortRow_9_SortIn];
					row15.title = current_tSortRow_9_SortIn.title;
					row15.gainouperte = current_tSortRow_9_SortIn.gainouperte;
					// increase number of line sorted
					nb_line_tSortRow_9_SortIn++;

					/**
					 * [tSortRow_9_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_9_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_9";

					currentComponent = "tSortRow_9_SortIn";

					tos_count_tSortRow_9_SortIn++;

					/**
					 * [tSortRow_9_SortIn main ] stop
					 */

					/**
					 * [tSortRow_9_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_9";

					currentComponent = "tSortRow_9_SortIn";

					/**
					 * [tSortRow_9_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_6 main ] start
					 */

					currentComponent = "tFileOutputExcel_6";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row15"

						);
					}

					if (row15.title != null) {

//modif start

						columnIndex_tFileOutputExcel_6 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_6 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_6,
								startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
								row15.title);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_6.addCell(cell_0_tFileOutputExcel_6);
						int currentWith_0_tFileOutputExcel_6 = cell_0_tFileOutputExcel_6.getContents().trim().length();
						fitWidth_tFileOutputExcel_6[0] = fitWidth_tFileOutputExcel_6[0] > currentWith_0_tFileOutputExcel_6
								? fitWidth_tFileOutputExcel_6[0]
								: currentWith_0_tFileOutputExcel_6 + 2;
					}

//modif start

					columnIndex_tFileOutputExcel_6 = 1;

					jxl.write.WritableCell cell_1_tFileOutputExcel_6 = new jxl.write.Number(
							columnIndex_tFileOutputExcel_6, startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
							row15.gainouperte);
//modif start					
					// If we keep the cell format from the existing cell in sheet

//modif ends							
					writableSheet_tFileOutputExcel_6.addCell(cell_1_tFileOutputExcel_6);
					int currentWith_1_tFileOutputExcel_6 = String
							.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_6).getValue()).trim().length();
					currentWith_1_tFileOutputExcel_6 = currentWith_1_tFileOutputExcel_6 > 10 ? 10
							: currentWith_1_tFileOutputExcel_6;
					fitWidth_tFileOutputExcel_6[1] = fitWidth_tFileOutputExcel_6[1] > currentWith_1_tFileOutputExcel_6
							? fitWidth_tFileOutputExcel_6[1]
							: currentWith_1_tFileOutputExcel_6 + 2;
					nb_line_tFileOutputExcel_6++;

					tos_count_tFileOutputExcel_6++;

					/**
					 * [tFileOutputExcel_6 main ] stop
					 */

					/**
					 * [tFileOutputExcel_6 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_6";

					/**
					 * [tFileOutputExcel_6 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_6 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_6";

					/**
					 * [tFileOutputExcel_6 process_data_end ] stop
					 */

					/**
					 * [tSortRow_9_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_9";

					currentComponent = "tSortRow_9_SortIn";

					/**
					 * [tSortRow_9_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_9_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_9";

					currentComponent = "tSortRow_9_SortIn";

				}

				globalMap.put("tSortRow_9_SortIn_NB_LINE", nb_line_tSortRow_9_SortIn);

				ok_Hash.put("tSortRow_9_SortIn", true);
				end_Hash.put("tSortRow_9_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_9_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_6 end ] start
				 */

				currentComponent = "tFileOutputExcel_6";

				writeableWorkbook_tFileOutputExcel_6.write();
				writeableWorkbook_tFileOutputExcel_6.close();
				if (headerIsInserted_tFileOutputExcel_6 && nb_line_tFileOutputExcel_6 > 0) {
					nb_line_tFileOutputExcel_6 = nb_line_tFileOutputExcel_6 - 1;
				}
				globalMap.put("tFileOutputExcel_6_NB_LINE", nb_line_tFileOutputExcel_6);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row15");
				}

				ok_Hash.put("tFileOutputExcel_6", true);
				end_Hash.put("tFileOutputExcel_6", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_6 end ] stop
				 */

				/**
				 * [tFileOutputExcel_1 end ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				writeableWorkbook_tFileOutputExcel_1.write();
				writeableWorkbook_tFileOutputExcel_1.close();
				if (headerIsInserted_tFileOutputExcel_1 && nb_line_tFileOutputExcel_1 > 0) {
					nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 - 1;
				}
				globalMap.put("tFileOutputExcel_1_NB_LINE", nb_line_tFileOutputExcel_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row5");
				}

				ok_Hash.put("tFileOutputExcel_1", true);
				end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tSortRow_9_SortIn"
			globalMap.remove("tSortRow_9");

			// free memory for "tAggregateRow_1_AGGIN"
			globalMap.remove("tAggregateRow_1");

			// free memory for "tSortRow_8_SortIn"
			globalMap.remove("tSortRow_8");

			// free memory for "tSortRow_7_SortIn"
			globalMap.remove("tSortRow_7");

			// free memory for "tSortRow_6_SortIn"
			globalMap.remove("tSortRow_6");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row3");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row4");

			try {

				/**
				 * [tFileInputExcel_1 finally ] start
				 */

				currentComponent = "tFileInputExcel_1";

				/**
				 * [tFileInputExcel_1 finally ] stop
				 */

				/**
				 * [tFilterColumns_1 finally ] start
				 */

				currentComponent = "tFilterColumns_1";

				/**
				 * [tFilterColumns_1 finally ] stop
				 */

				/**
				 * [tFilterRow_1 finally ] start
				 */

				currentComponent = "tFilterRow_1";

				/**
				 * [tFilterRow_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tSortRow_6_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_6";

				currentComponent = "tSortRow_6_SortOut";

				/**
				 * [tSortRow_6_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_6_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_6";

				currentComponent = "tSortRow_6_SortIn";

				/**
				 * [tSortRow_6_SortIn finally ] stop
				 */

				/**
				 * [tSortRow_7_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_7";

				currentComponent = "tSortRow_7_SortOut";

				/**
				 * [tSortRow_7_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_7_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_7";

				currentComponent = "tSortRow_7_SortIn";

				/**
				 * [tSortRow_7_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_3 finally ] start
				 */

				currentComponent = "tFileOutputExcel_3";

				/**
				 * [tFileOutputExcel_3 finally ] stop
				 */

				/**
				 * [tSortRow_8_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_8";

				currentComponent = "tSortRow_8_SortOut";

				/**
				 * [tSortRow_8_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_8_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_8";

				currentComponent = "tSortRow_8_SortIn";

				/**
				 * [tSortRow_8_SortIn finally ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				/**
				 * [tAggregateRow_1_AGGOUT finally ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGIN finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGIN";

				/**
				 * [tAggregateRow_1_AGGIN finally ] stop
				 */

				/**
				 * [tFileOutputExcel_5 finally ] start
				 */

				currentComponent = "tFileOutputExcel_5";

				/**
				 * [tFileOutputExcel_5 finally ] stop
				 */

				/**
				 * [tSortRow_9_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_9";

				currentComponent = "tSortRow_9_SortOut";

				/**
				 * [tSortRow_9_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_9_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_9";

				currentComponent = "tSortRow_9_SortIn";

				/**
				 * [tSortRow_9_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_6 finally ] start
				 */

				currentComponent = "tFileOutputExcel_6";

				/**
				 * [tFileOutputExcel_6 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_1 finally ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				/**
				 * [tFileOutputExcel_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}

	public static class row3Struct implements routines.system.IPersistableComparableLookupRow<row3Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movie_id;

		public Integer getMovie_id() {
			return this.movie_id;
		}

		public Long budget;

		public Long getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movie_id == null) ? 0 : this.movie_id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row3Struct other = (row3Struct) obj;

			if (this.movie_id == null) {
				if (other.movie_id != null)
					return false;

			} else if (!this.movie_id.equals(other.movie_id))

				return false;

			return true;
		}

		public void copyDataTo(row3Struct other) {

			other.movie_id = this.movie_id;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row3Struct other) {

			other.movie_id = this.movie_id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movie_id = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.movie_id = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movie_id, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movie_id, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				length = dis.readByte();
				if (length == -1) {
					this.budget = null;
				} else {
					this.budget = dis.readLong();
				}

				length = dis.readByte();
				if (length == -1) {
					this.revenue = null;
				} else {
					this.revenue = dis.readLong();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				length = objectIn.readByte();
				if (length == -1) {
					this.budget = null;
				} else {
					this.budget = objectIn.readLong();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.revenue = null;
				} else {
					this.revenue = objectIn.readLong();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				if (this.budget == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.budget);
				}

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				if (this.budget == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeLong(this.budget);
				}

				if (this.revenue == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movie_id=" + String.valueOf(movie_id));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movie_id, other.movie_id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();

				/**
				 * [tAdvancedHash_row3 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row3", false);
				start_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tAdvancedHash_row3 = 0;

				// connection name:row3
				// source node:tFileInputDelimited_1 - inputs:(after_tFileInputExcel_1)
				// outputs:(row3,row3) | target node:tAdvancedHash_row3 - inputs:(row3)
				// outputs:()
				// linked node: tMap_1 - inputs:(row2,row3,row4) outputs:(page1,page2,page3)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row3 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row3Struct>getLookup(matchingModeEnum_row3);

				globalMap.put("tHash_Lookup_row3", tHash_Lookup_row3);

				/**
				 * [tAdvancedHash_row3 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C:/Users/willi/Documents/COURS Aivancity/Cours/Data Pipeline/Talend/moviesIncome.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/willi/Documents/COURS Aivancity/Cours/Data Pipeline/Talend/moviesIncome.csv",
								"UTF-8", ";", "\n", false, 1, 0, limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row3 = null;

						row3 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row3 = new row3Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row3.movie_id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"movie_id", "row3", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row3.movie_id = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 1;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row3.budget = ParserUtils.parseTo_Long(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"budget", "row3", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row3.budget = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 2;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row3.revenue = ParserUtils.parseTo_Long(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"revenue", "row3", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row3.revenue = null;

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							row3 = null;

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row3"
						if (row3 != null) {

							/**
							 * [tAdvancedHash_row3 main ] start
							 */

							currentComponent = "tAdvancedHash_row3";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							row3Struct row3_HashRow = new row3Struct();

							row3_HashRow.movie_id = row3.movie_id;

							row3_HashRow.budget = row3.budget;

							row3_HashRow.revenue = row3.revenue;

							tHash_Lookup_row3.put(row3_HashRow);

							tos_count_tAdvancedHash_row3++;

							/**
							 * [tAdvancedHash_row3 main ] stop
							 */

							/**
							 * [tAdvancedHash_row3 process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_row3";

							/**
							 * [tAdvancedHash_row3 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row3 process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_row3";

							/**
							 * [tAdvancedHash_row3 process_data_end ] stop
							 */

						} // End of branch "row3"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("C:/Users/willi/Documents/COURS Aivancity/Cours/Data Pipeline/Talend/moviesIncome.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_row3 end ] start
				 */

				currentComponent = "tAdvancedHash_row3";

				tHash_Lookup_row3.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tAdvancedHash_row3", true);
				end_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row3 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row3 finally ] start
				 */

				currentComponent = "tAdvancedHash_row3";

				/**
				 * [tAdvancedHash_row3 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class row4Struct implements routines.system.IPersistableComparableLookupRow<row4Struct> {
		final static byte[] commonByteArrayLock_DATAENGINEERTP_DataEngTP = new byte[0];
		static byte[] commonByteArray_DATAENGINEERTP_DataEngTP = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row4Struct other = (row4Struct) obj;

			if (this.title == null) {
				if (other.title != null)
					return false;

			} else if (!this.title.equals(other.title))

				return false;

			return true;
		}

		public void copyDataTo(row4Struct other) {

			other.title = this.title;
			other.popularity = this.popularity;
			other.vote_average = this.vote_average;
			other.vote_count = this.vote_count;

		}

		public void copyKeysDataTo(row4Struct other) {

			other.title = this.title;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATAENGINEERTP_DataEngTP.length) {
					if (length < 1024 && commonByteArray_DATAENGINEERTP_DataEngTP.length == 0) {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[1024];
					} else {
						commonByteArray_DATAENGINEERTP_DataEngTP = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length);
				strReturn = new String(commonByteArray_DATAENGINEERTP_DataEngTP, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATAENGINEERTP_DataEngTP) {

				try {

					int length = 0;

					this.title = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				length = dis.readByte();
				if (length == -1) {
					this.popularity = null;
				} else {
					this.popularity = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.vote_average = null;
				} else {
					this.vote_average = dis.readFloat();
				}

				this.vote_count = readInteger(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				length = objectIn.readByte();
				if (length == -1) {
					this.popularity = null;
				} else {
					this.popularity = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.vote_average = null;
				} else {
					this.vote_average = objectIn.readFloat();
				}

				this.vote_count = readInteger(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				writeInteger(this.vote_count, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				if (this.popularity == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.popularity);
				}

				if (this.vote_average == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.vote_average);
				}

				writeInteger(this.vote_count, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.title, other.title);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputXML_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();

				/**
				 * [tAdvancedHash_row4 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row4", false);
				start_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tAdvancedHash_row4 = 0;

				// connection name:row4
				// source node:tFileInputXML_1 - inputs:(after_tFileInputExcel_1)
				// outputs:(row4,row4) | target node:tAdvancedHash_row4 - inputs:(row4)
				// outputs:()
				// linked node: tMap_1 - inputs:(row2,row3,row4) outputs:(page1,page2,page3)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row4 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row4Struct>getLookup(matchingModeEnum_row4);

				globalMap.put("tHash_Lookup_row4", tHash_Lookup_row4);

				/**
				 * [tAdvancedHash_row4 begin ] stop
				 */

				/**
				 * [tFileInputXML_1 begin ] start
				 */

				ok_Hash.put("tFileInputXML_1", false);
				start_Hash.put("tFileInputXML_1", System.currentTimeMillis());

				currentComponent = "tFileInputXML_1";

				int tos_count_tFileInputXML_1 = 0;

				int nb_line_tFileInputXML_1 = 0;

				String os_tFileInputXML_1 = System.getProperty("os.name").toLowerCase();
				boolean isWindows_tFileInputXML_1 = false;
				if (os_tFileInputXML_1.indexOf("windows") > -1 || os_tFileInputXML_1.indexOf("nt") > -1) {
					isWindows_tFileInputXML_1 = true;
				}
				class NameSpaceTool_tFileInputXML_1 {

					public java.util.HashMap<String, String> xmlNameSpaceMap = new java.util.HashMap<String, String>();

					private java.util.List<String> defualtNSPath = new java.util.ArrayList<String>();

					public void countNSMap(org.dom4j.Element el) {
						for (org.dom4j.Namespace ns : (java.util.List<org.dom4j.Namespace>) el.declaredNamespaces()) {
							if (ns.getPrefix().trim().length() == 0) {
								xmlNameSpaceMap.put("pre" + defualtNSPath.size(), ns.getURI());
								String path = "";
								org.dom4j.Element elTmp = el;
								while (elTmp != null) {
									if (elTmp.getNamespacePrefix() != null && elTmp.getNamespacePrefix().length() > 0) {
										path = "/" + elTmp.getNamespacePrefix() + ":" + elTmp.getName() + path;
									} else {
										path = "/" + elTmp.getName() + path;
									}
									elTmp = elTmp.getParent();
								}
								defualtNSPath.add(path);
							} else {
								xmlNameSpaceMap.put(ns.getPrefix(), ns.getURI());
							}

						}
						for (org.dom4j.Element e : (java.util.List<org.dom4j.Element>) el.elements()) {
							countNSMap(e);
						}
					}

					private final org.talend.xpath.XPathUtil util = new org.talend.xpath.XPathUtil();

					{
						util.setDefaultNSPath(defualtNSPath);
					}

					public String addDefaultNSPrefix(String path) {
						return util.addDefaultNSPrefix(path);
					}

					public String addDefaultNSPrefix(String relativeXpression, String basePath) {
						return util.addDefaultNSPrefix(relativeXpression, basePath);
					}

				}

				class XML_API_tFileInputXML_1 {
					public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
						if (node != null && node instanceof org.dom4j.Element) {
							org.dom4j.Attribute attri = ((org.dom4j.Element) node).attribute("nil");
							if (attri != null && ("true").equals(attri.getText())) {
								return true;
							}
						}
						return false;
					}

					public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
						return node == null ? true : false;
					}

					public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
						if (node != null) {
							return node.getText().length() == 0;
						}
						return false;
					}
				}

				org.dom4j.io.SAXReader reader_tFileInputXML_1 = new org.dom4j.io.SAXReader();
				Object filename_tFileInputXML_1 = null;
				try {
					filename_tFileInputXML_1 = "C:/Users/willi/Documents/COURS Aivancity/Cours/Data Pipeline/Talend/moviesRatings.xml";
				} catch (java.lang.Exception e) {
					globalMap.put("tFileInputXML_1_ERROR_MESSAGE", e.getMessage());

					System.err.println(e.getMessage());

				}
				if (filename_tFileInputXML_1 != null && filename_tFileInputXML_1 instanceof String
						&& filename_tFileInputXML_1.toString().startsWith("//")) {
					if (!isWindows_tFileInputXML_1) {
						filename_tFileInputXML_1 = filename_tFileInputXML_1.toString().replaceFirst("//", "/");
					}
				}

				boolean isValidFile_tFileInputXML_1 = true;
				org.dom4j.Document doc_tFileInputXML_1 = null;
				java.io.Closeable toClose_tFileInputXML_1 = null;
				try {
					if (filename_tFileInputXML_1 instanceof java.io.InputStream) {
						java.io.InputStream inputStream_tFileInputXML_1 = (java.io.InputStream) filename_tFileInputXML_1;
						toClose_tFileInputXML_1 = inputStream_tFileInputXML_1;
						doc_tFileInputXML_1 = reader_tFileInputXML_1.read(inputStream_tFileInputXML_1);
					} else {
						java.io.Reader unicodeReader_tFileInputXML_1 = new UnicodeReader(
								new java.io.FileInputStream(String.valueOf(filename_tFileInputXML_1)), "ISO-8859-15");
						toClose_tFileInputXML_1 = unicodeReader_tFileInputXML_1;
						org.xml.sax.InputSource in_tFileInputXML_1 = new org.xml.sax.InputSource(
								unicodeReader_tFileInputXML_1);
						doc_tFileInputXML_1 = reader_tFileInputXML_1.read(in_tFileInputXML_1);
					}
				} catch (java.lang.Exception e) {
					globalMap.put("tFileInputXML_1_ERROR_MESSAGE", e.getMessage());

					System.err.println(e.getMessage());
					isValidFile_tFileInputXML_1 = false;
				} finally {
					if (toClose_tFileInputXML_1 != null) {
						toClose_tFileInputXML_1.close();
					}
				}
				if (isValidFile_tFileInputXML_1) {
					NameSpaceTool_tFileInputXML_1 nsTool_tFileInputXML_1 = new NameSpaceTool_tFileInputXML_1();
					nsTool_tFileInputXML_1.countNSMap(doc_tFileInputXML_1.getRootElement());
					java.util.HashMap<String, String> xmlNameSpaceMap_tFileInputXML_1 = nsTool_tFileInputXML_1.xmlNameSpaceMap;

					org.dom4j.XPath x_tFileInputXML_1 = doc_tFileInputXML_1
							.createXPath(nsTool_tFileInputXML_1.addDefaultNSPrefix("/movies/movie/@title"));
					x_tFileInputXML_1.setNamespaceURIs(xmlNameSpaceMap_tFileInputXML_1);

					java.util.List<org.dom4j.Node> nodeList_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) x_tFileInputXML_1
							.selectNodes(doc_tFileInputXML_1);
					XML_API_tFileInputXML_1 xml_api_tFileInputXML_1 = new XML_API_tFileInputXML_1();
					String str_tFileInputXML_1 = "";
					org.dom4j.Node node_tFileInputXML_1 = null;

//init all mapping xpaths
					java.util.Map<Integer, org.dom4j.XPath> xpaths_tFileInputXML_1 = new java.util.HashMap<Integer, org.dom4j.XPath>();
					class XPathUtil_tFileInputXML_1 {

						public void initXPaths_0(java.util.Map<Integer, org.dom4j.XPath> xpaths,
								NameSpaceTool_tFileInputXML_1 nsTool,
								java.util.HashMap<String, String> xmlNameSpaceMap) {

							org.dom4j.XPath xpath_0 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix(".", "/movies/movie/@title"));
							xpath_0.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(0, xpath_0);

							org.dom4j.XPath xpath_1 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("../@popularity", "/movies/movie/@title"));
							xpath_1.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(1, xpath_1);

							org.dom4j.XPath xpath_2 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("../@vote_average", "/movies/movie/@title"));
							xpath_2.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(2, xpath_2);

							org.dom4j.XPath xpath_3 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("../@vote_count", "/movies/movie/@title"));
							xpath_3.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(3, xpath_3);

						}

						public void initXPaths(java.util.Map<Integer, org.dom4j.XPath> xpaths,
								NameSpaceTool_tFileInputXML_1 nsTool,
								java.util.HashMap<String, String> xmlNameSpaceMap) {

							initXPaths_0(xpaths, nsTool, xmlNameSpaceMap);

						}
					}
					XPathUtil_tFileInputXML_1 xPathUtil_tFileInputXML_1 = new XPathUtil_tFileInputXML_1();
					xPathUtil_tFileInputXML_1.initXPaths(xpaths_tFileInputXML_1, nsTool_tFileInputXML_1,
							xmlNameSpaceMap_tFileInputXML_1);
					for (org.dom4j.Node temp_tFileInputXML_1 : nodeList_tFileInputXML_1) {
						if (nb_line_tFileInputXML_1 >= 5000) {

							break;
						}
						nb_line_tFileInputXML_1++;

						row4 = null;
						row4 = null;
						boolean whetherReject_tFileInputXML_1 = false;
						row4 = new row4Struct();
						try {
							Object obj0_tFileInputXML_1 = xpaths_tFileInputXML_1.get(0).evaluate(temp_tFileInputXML_1);
							if (obj0_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj0_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj0_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj0_tFileInputXML_1 instanceof String
									|| obj0_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj0_tFileInputXML_1);
							} else if (obj0_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj0_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.title = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)) {
								row4.title = "";
							} else if (xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.title = null;
							} else {
								row4.title = str_tFileInputXML_1;
							}
							Object obj1_tFileInputXML_1 = xpaths_tFileInputXML_1.get(1).evaluate(temp_tFileInputXML_1);
							if (obj1_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj1_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj1_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj1_tFileInputXML_1 instanceof String
									|| obj1_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj1_tFileInputXML_1);
							} else if (obj1_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj1_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.popularity = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)
									|| xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.popularity = null;
							} else {
								row4.popularity = ParserUtils.parseTo_Float(str_tFileInputXML_1);
							}
							Object obj2_tFileInputXML_1 = xpaths_tFileInputXML_1.get(2).evaluate(temp_tFileInputXML_1);
							if (obj2_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj2_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj2_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj2_tFileInputXML_1 instanceof String
									|| obj2_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj2_tFileInputXML_1);
							} else if (obj2_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj2_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.vote_average = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)
									|| xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.vote_average = null;
							} else {
								row4.vote_average = ParserUtils.parseTo_Float(str_tFileInputXML_1);
							}
							Object obj3_tFileInputXML_1 = xpaths_tFileInputXML_1.get(3).evaluate(temp_tFileInputXML_1);
							if (obj3_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj3_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj3_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj3_tFileInputXML_1 instanceof String
									|| obj3_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj3_tFileInputXML_1);
							} else if (obj3_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj3_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.vote_count = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)
									|| xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.vote_count = null;
							} else {
								row4.vote_count = ParserUtils.parseTo_Integer(str_tFileInputXML_1);
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputXML_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputXML_1 = true;
							System.err.println(e.getMessage());
							row4 = null;
						}

						/**
						 * [tFileInputXML_1 begin ] stop
						 */

						/**
						 * [tFileInputXML_1 main ] start
						 */

						currentComponent = "tFileInputXML_1";

						tos_count_tFileInputXML_1++;

						/**
						 * [tFileInputXML_1 main ] stop
						 */

						/**
						 * [tFileInputXML_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputXML_1";

						/**
						 * [tFileInputXML_1 process_data_begin ] stop
						 */
// Start of branch "row4"
						if (row4 != null) {

							/**
							 * [tAdvancedHash_row4 main ] start
							 */

							currentComponent = "tAdvancedHash_row4";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row4"

								);
							}

							row4Struct row4_HashRow = new row4Struct();

							row4_HashRow.title = row4.title;

							row4_HashRow.popularity = row4.popularity;

							row4_HashRow.vote_average = row4.vote_average;

							row4_HashRow.vote_count = row4.vote_count;

							tHash_Lookup_row4.put(row4_HashRow);

							tos_count_tAdvancedHash_row4++;

							/**
							 * [tAdvancedHash_row4 main ] stop
							 */

							/**
							 * [tAdvancedHash_row4 process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_row4";

							/**
							 * [tAdvancedHash_row4 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row4 process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_row4";

							/**
							 * [tAdvancedHash_row4 process_data_end ] stop
							 */

						} // End of branch "row4"

						/**
						 * [tFileInputXML_1 process_data_end ] start
						 */

						currentComponent = "tFileInputXML_1";

						/**
						 * [tFileInputXML_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputXML_1 end ] start
						 */

						currentComponent = "tFileInputXML_1";

					}
				}
				globalMap.put("tFileInputXML_1_NB_LINE", nb_line_tFileInputXML_1);

				ok_Hash.put("tFileInputXML_1", true);
				end_Hash.put("tFileInputXML_1", System.currentTimeMillis());

				/**
				 * [tFileInputXML_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_row4 end ] start
				 */

				currentComponent = "tAdvancedHash_row4";

				tHash_Lookup_row4.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tAdvancedHash_row4", true);
				end_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputXML_1 finally ] start
				 */

				currentComponent = "tFileInputXML_1";

				/**
				 * [tFileInputXML_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row4 finally ] start
				 */

				currentComponent = "tAdvancedHash_row4";

				/**
				 * [tAdvancedHash_row4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final DataEngTP DataEngTPClass = new DataEngTP();

		int exitCode = DataEngTPClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = DataEngTP.class.getClassLoader()
					.getResourceAsStream("dataengineertp/dataengtp_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = DataEngTP.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputExcel_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputExcel_1) {
			globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);

			e_tFileInputExcel_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : DataEngTP");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 332741 characters generated by Talend Open Studio for Data Integration on the
 * 13 octobre 2023, 16:32:20 CEST
 ************************************************************************************************/